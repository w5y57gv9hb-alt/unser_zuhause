# Unser Zuhause – PWA-Starter

Eine mobiloptimierte React/Vite-Grundlage im warmen Creme-/Terrakotta-Stil der Vorlage.

## Was schon funktioniert
- Startseite und Navigation für Start, Rezepte, Einkauf, Vorrat und Restaurants
- Demo-Rezepte, Suche, Rezept anlegen/bearbeiten/löschen
- Zutaten eines Rezepts zur Einkaufsliste hinzufügen
- Einkaufsposten abhaken und löschen
- Vorrat und Restaurant-Wunschliste pflegen
- Hell-/Dunkelmodus
- lokale Speicherung im Browser (localStorage)
- Supabase-Paket, Umgebungsvariablen-Beispiel und SQL-Grundschema als nächste Integrationsstufe

## Lokal starten
Voraussetzung: Node.js 20 oder neuer.

```bash
npm install
npm run dev
```

Dann die angezeigte lokale URL öffnen.

## Supabase einrichten
1. Ein Projekt in Supabase anlegen.
2. `.env.example` nach `.env` kopieren und URL sowie anon key eintragen.
3. `supabase/schema.sql` im SQL Editor ausführen.
4. Authentifizierung, Haushaltszuordnung und Row Level Security (RLS) sorgfältig konfigurieren.
5. Die React-Datenzugriffe in `src/main.jsx` an die Tabellen anbinden. Das Projekt verbindet sich aktuell **noch nicht automatisch** mit Supabase; die Oberfläche arbeitet bewusst lokal im Demo-Modus, damit keine Daten ohne eingerichtete Sicherheitsregeln übertragen werden.

## Auf dem iPhone installieren
Nach dem Deployment über HTTPS in Safari öffnen → Teilen → „Zum Home-Bildschirm“. Für ein vollständiges Offline-Erlebnis sollte zusätzlich ein Service Worker mit Cache-Strategie ergänzt werden.

## Wichtig
Dies ist ein startfähiger Prototyp, kein bereits gehosteter oder vollständig synchronisierter Produktivdienst. Die ursprüngliche HTML-Datei nutzt eine vorhandene `claude.use(...)`-Umgebung; deren Daten und Bilder werden durch diesen Starter nicht automatisch migriert. Vor dem Umstieg sollten vorhandene Daten exportiert und die gemeinsame Datenbankanbindung eingerichtet werden.
