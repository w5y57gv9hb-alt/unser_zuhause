UNSER ZUHAUSE – PRIVATE DEMO OHNE SUPABASE

Inhalt:
- index.html: bedienbare App-Demo
- manifest.webmanifest: Installationsdaten
- sw.js: Offline-Cache nach dem ersten Laden
- icon.svg: App-Symbol

Funktionen:
- Rezepte hinzufügen, bearbeiten und löschen
- Rezeptsuche
- Zutaten auf die Einkaufsliste setzen
- Einkaufsliste abhaken und bearbeiten
- Vorräte verwalten
- Dark Mode
- lokale Speicherung im jeweiligen Browser

Wichtig:
Dies ist noch keine gemeinsam synchronisierte App. Daten bleiben lokal auf dem jeweiligen Gerät/Browser.
Für die Installation als PWA auf dem iPhone muss die App über eine HTTPS-Adresse bereitgestellt werden.
Danach in Safari öffnen -> Teilen -> Zum Home-Bildschirm.
Die ZIP-Datei ist nicht selbst ein App-Store-Paket.
